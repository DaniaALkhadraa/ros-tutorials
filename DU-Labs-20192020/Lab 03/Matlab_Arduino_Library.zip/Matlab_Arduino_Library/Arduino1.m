function[obj,flag] = Arduino1(comPort)
[obj,flag] = setupSerial(comPort);
end