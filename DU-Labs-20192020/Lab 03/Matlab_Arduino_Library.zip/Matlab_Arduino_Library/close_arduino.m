function[] = close_arduino(ser)
    fclose(ser)
end