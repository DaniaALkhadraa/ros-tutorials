#!/usr/bin/env python
import rospy
from std_msgs.msg import String

rospy.init_node('publisher_node')

pub = rospy.Publisher('my_topic', String, queue_size=10)
rate = rospy.Rate(1) #rate in Hz

my_msg = String()
my_msg.data = "Hello, ROS!!"
print('Start Publishing...')
while not rospy.is_shutdown():
    pub.publish(my_msg)
    rate.sleep()




