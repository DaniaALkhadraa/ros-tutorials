#!/usr/bin/env python
import rospy
from std_msgs.msg import String

def cb(msg):
    print(msg.data)

rospy.init_node('subscriber_node')

rospy.Subscriber('my_topic', String, callback = cb)

#rospy.spin()

while not rospy.is_shutdown():
    pass

